# MiniProject
Miniproject for TIINCO Course. 

For run - Run script miniPro.m
